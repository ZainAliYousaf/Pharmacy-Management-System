﻿-- ===========================
-- DATABASE CREATION
-- ===========================
CREATE DATABASE PharmacyDB;
GO

USE PharmacyDB;
GO

-- ===========================
-- 1. Admin Table
-- ===========================
CREATE TABLE Admin (
    AdminID INT PRIMARY KEY IDENTITY(1,1),
    Username VARCHAR(50) UNIQUE NOT NULL,
    Password VARCHAR(255) NOT NULL
);

-- Insert default admin
INSERT INTO Admin (Username, Password)
VALUES ('admin', '123');

-- ===========================
-- 2. Suppliers Table
-- ===========================
CREATE TABLE Suppliers (
    SupplierID INT PRIMARY KEY IDENTITY(1,1),
    SupplierName VARCHAR(100) NOT NULL,
    Contact VARCHAR(50),
    Address VARCHAR(200)
);

-- ===========================
-- 3. Medicines Table
-- ===========================
CREATE TABLE Medicines (
    MedicineID INT PRIMARY KEY IDENTITY(1,1),
    MedicineName VARCHAR(100) NOT NULL,
    Category VARCHAR(50),
    SupplierID INT,
    Quantity INT NOT NULL,
    CostPrice DECIMAL(10,2) NOT NULL,
    SellingPrice DECIMAL(10,2) NOT NULL,
    ManufactureDate DATE,
    ExpiryDate DATE,
    CONSTRAINT FK_Medicines_Supplier
         FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID)
);

-- ===========================
-- 4. Sales Table
-- ===========================
CREATE TABLE Sales (
    SaleID INT PRIMARY KEY IDENTITY(1,1),
    SaleDate DATETIME NOT NULL DEFAULT GETDATE(),
    TotalAmount DECIMAL(10,2) NOT NULL
);

-- ===========================
-- 5. SaleItems Table
-- ===========================
CREATE TABLE SaleItems (
    SaleItemID INT PRIMARY KEY IDENTITY(1,1),
    SaleID INT NOT NULL,
    MedicineID INT NOT NULL,
    Quantity INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    CONSTRAINT FK_SaleItems_Sale
        FOREIGN KEY (SaleID) REFERENCES Sales(SaleID),
    CONSTRAINT FK_SaleItems_Medicine
        FOREIGN KEY (MedicineID) REFERENCES Medicines(MedicineID)
);
go
-- ===========================
-- Low Stock Alert View (For WinForms)
-- ===========================
CREATE VIEW LowStockView AS
SELECT MedicineID, MedicineName, Quantity
FROM Medicines
WHERE Quantity < 10;   -- threshold
go
-- ===========================
-- Expiry Alert View
-- ===========================
CREATE VIEW ExpiryAlertView AS
SELECT MedicineID, MedicineName, ExpiryDate
FROM Medicines
WHERE ExpiryDate <= DATEADD(month, 1, GETDATE()); -- next 30 days
go
-- ===========================
-- Sales Report View
-- ===========================
CREATE VIEW SalesReportView AS
SELECT 
    S.SaleID,
    S.SaleDate,
    SUM(SI.Quantity * SI.Price) AS TotalSale
FROM Sales S
JOIN SaleItems SI ON S.SaleID = SI.SaleID
GROUP BY S.SaleID, S.SaleDate;
go