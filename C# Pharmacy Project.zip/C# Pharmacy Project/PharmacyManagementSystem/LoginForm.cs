﻿using Pharmacy.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PharmacyManagementSystem
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
         
              string username = txtUsername.Text.Trim();
              string password = txtPassword.Text.Trim();

                if (username == "" || password == "")
                {
                    MessageBox.Show("Please enter username and password");
                    return;
                }

                DatabaseConnection db = new DatabaseConnection();
                SqlConnection conn = db.GetConnection();

                try
                {
                    conn.Open();
                    string query = "SELECT * FROM Admin WHERE Username=@user AND Password=@pass";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@user", username);
                    cmd.Parameters.AddWithValue("@pass", password);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        MessageBox.Show("Login Successful!");

                        // Open Dashboard form next
                        DashboardForm dashboard = new DashboardForm();
                        dashboard.Show();

                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid credentials!");
                    }

                    conn.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }



